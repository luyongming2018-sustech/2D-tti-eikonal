clear
n1=1200;
n2=901;

x=[1:1:n1];
y=[1:1:n2];

dx=0.005;
dz=0.005;


lx=(n1-1)*dx;
lz=(n2-1)*dz;
xr=[0:dx:lx];
zr=[0:dz:lz];
fid1=fopen('../para/vp.bin','rb');
Vp=fread(fid1,[n2 n1],'float');
fclose(fid1);

[X,Y]=meshgrid(x,y);
fp1=fopen('qsh_traveltime.bin', 'rb');
T1=fread(fp1,[n2,n1],'float');
fclose(fp1);
imagesc(xr,zr,Vp);
shading interp
colorbar
colormap('jet');
h=colorbar;set(get(h,'Title'),'string','m/s');
hold on

[d,b]=contour(xr,zr,T1,10,'k', 'linewidth',2.0);

xlim([min(xr) max(xr)]); 
ylim([min(zr) max(zr)]);
% legend('Analytical','2ndFSM',Location='north',Orientation='horizontal');
set(gca,'ydir', 'reverse');
set(gca,'FontSize',15,'LineWidth',1);
xlabel('Distance (km)','Fontname','Times New Roman','fontsize',20);set(gca,'XAxisLocation','top');
ylabel('Depth (km)','Fontname','Times New Roman','fontsize',20);

%clabel=clabel(d,'manual', 'fontsize',14);





