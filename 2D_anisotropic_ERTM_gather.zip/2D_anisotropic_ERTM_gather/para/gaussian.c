#include<stdio.h>
#include<math.h>
#include<stdlib.h>

void g_blur(float **a,int n1,int n2,int nsp,FILE *fp);
void main()
{
	float **a,**b,dist1,dist2,cx,cz;
	int nx,nz,ix,iz,nall,nn;
	FILE *fp;
	/*nx=1151;
	nz=401;*/
	nx=1001;
	nz=801;
	nall=nx*nz;

	a=(float**)calloc(nx,sizeof(float*));
	b=(float**)calloc(nx,sizeof(float*));
	for(ix=0;ix<nx;ix++){
		a[ix]=(float*)calloc(nz,sizeof(float));
		b[ix]=(float*)calloc(nz,sizeof(float));
	}

	fp=fopen("vp.bin","rb");
	for(ix=0;ix<nx;ix=ix+1){
		for(iz=0;iz<nz;iz++){
			
			fread(&a[ix][iz],sizeof(float),1,fp);
			 //[ix][iz]=1.0/a[ix][iz];
			a[ix][iz]=1.0/a[ix][iz];   
			  
		}
	}
	fclose(fp);
	//exit(0);
	g_blur(a,nx,nz,100,fp);//*/	
	fp=fopen("vp_m.bin","wb");
	for(ix=0;ix<nx;ix=ix+1){
		for(iz=0;iz<nz;iz++){
			a[ix][iz]=1.0/a[ix][iz];
			fwrite(&a[ix][iz],sizeof(float),1,fp);    
		}
	}
	fclose(fp);
}

void g_blur(float **a,int n1,int n2,int nsp,FILE *fp)
{
	int n1e,n2e,i1,i2,i11,i22;
	double PI=3.141592653;
	float **b;
	double a1,b1,dist1,dist2;
	n1e=n1+2*nsp;
	n2e=n2+2*nsp;
	b=(float**)calloc(n1e,sizeof(float*));
	for(i1=0;i1<n1e;i1++){
		b[i1]=(float*)calloc(n2e,sizeof(float));
	}
	for(i1=0;i1<n1;i1++){
		for(i2=0;i2<n2;i2++){
			b[i1+nsp][i2+nsp]=a[i1][i2];
		}
	}
	for(i1=0;i1<n1;i1++){
		for(i2=0;i2<nsp;i2++){
			b[i1+nsp][i2]=a[i1][0];
			b[i1+nsp][i2+n2+nsp]=a[i1][n2-1];
		}
	}
	for(i1=0;i1<nsp;i1++){
		for(i2=0;i2<n2;i2++){
			b[i1][i2+nsp]=a[0][i2];
			b[nsp+n1+i1][i2+nsp]=a[n1-1][i2];
		}
	}
	for(i1=0;i1<nsp;i1++){
		for(i2=0;i2<nsp;i2++){
			b[i1][i2]=a[0][0];
			b[i1][nsp+n2+i2]=a[0][n2-1];
			b[i1+nsp+n1][i2]=a[n1-1][0];
			b[i1+nsp+n1][i2+nsp+n2]=a[n1-1][n2-1];
		}
	}

	for(i1=nsp;i1<n1+nsp;i1++){
		for(i2=nsp;i2<n2+nsp;i2++){
			a1=0;
			//printf("i1=%d,i2=%d\n",i1,i2);
			for(i11=i1-nsp;i11<=i1+nsp;i11++){
				for(i22=i2-nsp;i22<=i2+nsp;i22++){
					dist1=i11-i1;
					dist2=i22-i2;
					b1=exp(-(dist1*dist1+dist2*dist2)/(2.0*nsp/3.0*nsp/3.0));
					a1+=b1*b[i11][i22];
				}
			}
			a[i1-nsp][i2-nsp]=a1;
		}
	}	
	a1=0;
	for(i11=0;i11<=2.0*nsp;i11++){
		for(i22=0;i22<=2.0*nsp;i22++){
			dist1=i11-nsp;
			dist2=i22-nsp;
			b1=exp(-(dist1*dist1+dist2*dist2)/(2.0*nsp/3.0*nsp/3.0));
			a1+=b1;
		}
	}

	for(i1=0;i1<n1;i1++){
		for(i2=0;i2<n2;i2++){
			a[i1][i2]/=a1;
		}
	}
	fp=fopen("file.bin","wb");
	for(i1=0;i1<n1;i1++){
		for(i2=0;i2<n2;i2++){
			fwrite(&a[i1][i2],sizeof(float),1,fp);
		}
	}
	fclose(fp);
}
