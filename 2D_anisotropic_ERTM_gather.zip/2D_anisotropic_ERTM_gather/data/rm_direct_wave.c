#include<stdio.h>
#include<malloc.h>
#include<math.h>
#include<stdlib.h>
#include <string.h>
int main(int argc,char *argv[])
{
	int i,j,k;
	char FN5[250], FN6[250], FN7[250];
	char parfile[400];
	float *shot_x, *shot_z, *shot_Hos;
	FILE *fp,*fpsnap, *fpshot, *fpshot1; 
	int nt=4001;
	int nx=1001;
	int is;
	shot_Hos=(float*)calloc(nt*nx,sizeof(float));
	shot_x=(float*)calloc(nt*nx,sizeof(float));
	shot_z=(float*)calloc(nt*nx,sizeof(float));
	int nshot=101;
	for(is=1;is<nshot;is++){
		printf("is=%d\n",is);
		sprintf(FN5,"%s_%d_%s","shot",is,"x.dat");
		fpshot=fopen(FN5,"rb");
		fread(shot_Hos,sizeof(float),nx*nt,fpshot);
		fclose(fpshot); 
		
		sprintf(FN5,"%s_%d_%s","shot",is,"x1.dat");
		fpshot=fopen(FN5,"rb");
		fread(shot_x,sizeof(float),nx*nt,fpshot);
		fclose(fpshot); 
		for(i=0; i<nx; i++){
			for(j=0;j<nt;j++){
				shot_x[i*nt+j]=shot_Hos[i*nt+j]-shot_x[i*nt+j];
			}
		}

		sprintf(FN6,"%s_%d_%s","shot",is,"x.bin");
		fpshot=fopen(FN6,"wb");
		fwrite(shot_x,sizeof(float),nx*nt,fpshot);
		fclose(fpshot); 

		sprintf(FN7,"%s_%d_%s","shot",is,"z.dat");
		fpshot=fopen(FN7,"rb");
		fread(shot_Hos,sizeof(float),nx*nt,fpshot);
		fclose(fpshot); 
		sprintf(FN5,"%s_%d_%s","shot",is,"z1.dat");
		fpshot=fopen(FN5,"rb");
		fread(shot_z,sizeof(float),nx*nt,fpshot);
		fclose(fpshot); 
		for(i=0; i<nx; i++){
			for(j=0;j<nt;j++){
				shot_z[i*nt+j]=shot_Hos[i*nt+j]-shot_z[i*nt+j];
			}
		}
		sprintf(FN6,"%s_%d_%s","shot",is,"z.bin");
		fpshot=fopen(FN6,"wb");
		fwrite(shot_z,sizeof(float),nx*nt,fpshot);
		fclose(fpshot); 
	}

	return 0;
}
