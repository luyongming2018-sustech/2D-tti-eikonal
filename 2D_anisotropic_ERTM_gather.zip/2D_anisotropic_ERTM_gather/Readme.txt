Aouther: Yongming Lu, XiaoYi Wang and Tao Lei
ertm2d_fd.cu is the forward modeling code to gengerate the shot records
elastic_rtm2D.cu is the migration code to produce the images and gathers.

Run Step: Make->Makefile
the calculated migration results are in File->src/snapshots
img_and_gather.c is the code of stacking all images. 

File data is used to put the shot records
File para is used to put the model parameters: velocity, delta, epsilon, theta
File src is the code