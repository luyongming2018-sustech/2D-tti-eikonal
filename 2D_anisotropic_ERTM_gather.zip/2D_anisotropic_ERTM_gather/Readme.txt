Aouther: Yongming Lu, XiaoYi Wang and Tao Lei
ertm2d_fd.cu is the forward modeling code to gengerate the shot records
elastic_rtm2D.cu is the migration code to produce the images and gathers.
//---------------------------------------------
Software to be installed 
//--------------------------------------------
cuda:https://developer.nvidia.com/cuda-10.0-download-archive
CWP/SU:http://www.cwp.mines.edu/cwpcodes/

//-------------------------------
1.File data is used to put the shot records
2.File para is used to put the model parameters: velocity, delta, epsilon, theta
3.File src is the code and the calculated results(file snapshots):
model_parameter.dat
{
	1001 501 #nx and nz
	50 0 #shot interval dshot and depth grid sz
	5.0 #grid interval dx dz
	4001 0.0005 5 #sample time nt,dt and ndt
	20 #fpeak of wavelet
}# modfiy the parameters according to different model

//--------------------
run the code
//--------------------

cd  ./src
sh run.sh
{
	echo "Make file"
	make
	sleep 10
	echo "Foward modeling"
	for i in `seq 101` 
		do
		 ./ertm2d_fd ishot=$i  igpu=0 path=.. 
		done
	sleep 10
	echo "Imaging modeling"
	for i in `seq 101` 
		do
		 ./elastic_rtm2D ishot=$i  igpu=0 path=.. 
		done
	sleep 10
	echo "Data processing"
	./img
	./cutd
	sleep 10
	echo "Plot figure"
	sh plotimage.sh
}

After runing, you can obtain the figures(Taking the garben model as an example):
Images: img_pp.eps and img_ps.eps
Dip angle gather:dip_pp.eps and dip_ps.eps


