for i in `seq 360` 
    do
	 ./elastic_rtm2D ishot=$i  igpu=1 path=.. 
    done
