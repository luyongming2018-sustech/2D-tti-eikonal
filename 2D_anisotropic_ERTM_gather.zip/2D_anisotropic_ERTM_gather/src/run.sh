echo "Make file"
make
sleep 10
echo "Foward modeling"
for i in `seq 101` 
    do
	 ./ertm2d_fd ishot=$i  igpu=0 path=.. 
    done
sleep 10
echo "Imaging modeling"
for i in `seq 101` 
    do
	 ./elastic_rtm2D ishot=$i  igpu=0 path=.. 
    done
sleep 10
echo "Data processing"
./img
./cutd
sleep 10
echo "Plot figure"
sh plotimage.sh
