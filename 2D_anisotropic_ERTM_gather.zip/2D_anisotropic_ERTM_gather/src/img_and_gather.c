#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void g_blur(float **a,int n1,int n2,int nsp,FILE *fp)
{
	int n1e,n2e,i1,i2,i11,i22;
	//double PI=3.141592653;
	float **b;
	float **optc;
	double a1,b1,dist1,dist2;
	n1e=n1+2*nsp;
	n2e=n2+2*nsp;
	b=(float**)calloc(n1e,sizeof(float*));
	optc=(float**)calloc(2*nsp+1,sizeof(float*));
	for(i1=0;i1<n1e;i1++){
		b[i1]=(float*)calloc(n2e,sizeof(float));
		optc[i1]=(float*)calloc(2*nsp+1,sizeof(float));
	}

	for(i11=0;i11<=2.0*nsp;i11++){
		for(i22=0;i22<=2.0*nsp;i22++){
			dist1=i11-nsp;
			dist2=i22-nsp;
			optc[i11][i22]=exp(-(dist1*dist1+dist2*dist2)/(2.0*nsp/9.0*nsp));
		}
	}

	for(i1=0;i1<n1;i1++){
		for(i2=0;i2<n2;i2++){
			b[i1+nsp][i2+nsp]=a[i1][i2];
		}
	}
	for(i1=0;i1<n1;i1++){
		for(i2=0;i2<nsp;i2++){
			b[i1+nsp][i2]=a[i1][0];
			b[i1+nsp][i2+n2+nsp]=a[i1][n2-1];
		}
	}
	for(i1=0;i1<nsp;i1++){
		for(i2=0;i2<n2;i2++){
			b[i1][i2+nsp]=a[0][i2];
			b[nsp+n1+i1][i2+nsp]=a[n1-1][i2];
		}
	}
	for(i1=0;i1<nsp;i1++){
		for(i2=0;i2<nsp;i2++){
			b[i1][i2]=a[0][0];
			b[i1][nsp+n2+i2]=a[0][n2-1];
			b[i1+nsp+n1][i2]=a[n1-1][0];
			b[i1+nsp+n1][i2+nsp+n2]=a[n1-1][n2-1];
		}
	}

	for(i1=nsp;i1<n1+nsp;i1++){
		for(i2=nsp;i2<n2+nsp;i2++){
			a1=0;
			//printf("i1=%d\n",i1);
			for(i11=i1-nsp;i11<=i1+nsp;i11++){
				for(i22=i2-nsp;i22<=i2+nsp;i22++){
					a1+=optc[i11-(i1-nsp)][i22-(i2-nsp)]*b[i11][i22];
				}
			}
			a[i1-nsp][i2-nsp]=a1;
		}
	}	
	a1=0;
	for(i11=0;i11<=2.0*nsp;i11++){
		for(i22=0;i22<=2.0*nsp;i22++){
			dist1=i11-nsp;
			dist2=i22-nsp;
			b1=exp(-(dist1*dist1+dist2*dist2)/(2.0*nsp/9.0*nsp));
			a1+=b1;
		}
	}

	for(i1=0;i1<n1;i1++){
		for(i2=0;i2<n2;i2++){
			a[i1][i2]/=a1;
		}
	}
}
void main()
{
	float **input,**ss,a1,a2,a3;
	int ncdipg=60;
	float (*udp)[ncdipg],(*udp1)[ncdipg];
	int nx,nz,i,ix,iz,inum,nx1,nx2,j;
	char filename[100],fnum[10],iternum[10],type[10],path[100];

	FILE *fp;

	nx=1001;
	nz=501;
	input=(float**)calloc(nx,sizeof(float*));
	ss=(float **)calloc(nx,sizeof(float*));
      udp=(float(*)[ncdipg])calloc(nx*nz,sizeof(*udp));
      udp1=(float(*)[ncdipg])calloc(nx*nz,sizeof(*udp1));
	for(ix=0;ix<nx;ix++){
		input[ix]=(float*)calloc(nz,sizeof(float));
		ss[ix]=(float*)calloc(nz,sizeof(float));
	}

	sprintf(path,"%s","./snapshots/");
	sprintf(iternum,"%d",0);
	sprintf(type,"%s","pp");
	 for(i=0;i<101;i++){
		printf("i_ufo=%d\n",i);
		sprintf(fnum,"%d",(int)(i));
        strcpy(filename,path);
		strcat(filename,"Image_");
		strcat(filename,fnum);
		strcat(filename,"_");
		strcat(filename,type);
		strcat(filename,".bin");
		if((fp=fopen(filename,"rb"))==NULL){
			printf("cannnot open %s\n",filename);
			continue;
		}
		for(ix=0;ix<nx;ix++){
			for(iz=0;iz<nz;iz++){
				fread(&a1,sizeof(float),1,fp);
				input[ix][iz]+=a1;
			}
		}
		fclose(fp);  
		
       	        strcpy(filename,path);
		strcat(filename,"illum_");
		strcat(filename,fnum);
		strcat(filename,"_");
		strcat(filename,".bin");
		if((fp=fopen(filename,"rb"))==NULL){
			printf("cannnot open %s\n",filename);
			continue;
		}
		for(ix=0;ix<nx;ix++){
			for(iz=0;iz<nz;iz++){
				fread(&a3,sizeof(float),1,fp);
				ss[ix][iz]+=a3;
			}
		}
		fclose(fp); 
		strcpy(filename,path);
		strcat(filename,"Cdipg_");
	 	strcat(filename,fnum);
		strcat(filename,"_");
		strcat(filename,type);
		strcat(filename,".bin");
		if((fp=fopen(filename,"rb"))==NULL){
			printf("cannnot open %s\n",filename);
			continue;
		}
		printf("i_cdipg=%d\n",i);
		
		for(ix=0;ix<nx;ix++){
			for(j=0;j<ncdipg;j++){
			      for(iz=0;iz<nz;iz++){
				      fread(&a2,sizeof(float),1,fp);
				      udp[ix*nz+iz][j]+=a2;
			      }
		      }
		}
	    fclose(fp);//*/
     }
    strcpy(filename,"./vf1_g_dip_");
	strcat(filename,type);
	strcat(filename,".bin");
	fp=fopen(filename,"wb");
	for(ix=+0;ix<nx;ix++){
	    for(j=0;j<ncdipg;j++){
	    	for(iz=0;iz<nz;iz++){
		      a2=udp[ix*nz+iz][j];
		      fwrite(&a2,sizeof(float),1,fp);
		      udp[ix*nz+iz][j]=0;
	       }
		}
	}
	fclose(fp);//*/
   /* strcpy(filename,"./Image_");
	strcat(filename,type);
	strcat(filename,".bin");
	fp=fopen(filename,"rb");
	for(ix=0;ix<nx;ix++){
		for(iz=;iz<nz;iz++){
			//a1=input[ix][iz];
			fread(&a1,sizeof(float),1,fp);
			input[ix][iz]=a1;
		}
	}
	fclose(fp);*/

	g_blur(ss,nx,nz,20,fp);
	
	for(ix=0;ix<nx;ix++){
		for(iz=0;iz<nz;iz++){
		      a1=input[ix][iz];
			  a3=ss[ix][iz];
			if(a3>0){
			      input[ix][iz]=a1/a3;
			 }
		}
	}

	strcpy(filename,"./Image_gf_pp");
	strcat(filename,".bin");
	fp=fopen(filename,"wb");
	for(ix=0;ix<nx;ix++){
		for(iz=0;iz<nz;iz++){
			a1=input[ix][iz];
			fwrite(&a1,sizeof(float),1,fp);
			input[ix][iz]=0;
		}
	}
	fclose(fp);
	//exit(0);
	
	
	sprintf(path,"%s","./snapshots/");
	sprintf(iternum,"%d",0);
	sprintf(type,"%s","ps");
	 for(i=0;i<101;i++){
		printf("i_ufo=%d\n",i);
		sprintf(fnum,"%d",(int)(i));
        strcpy(filename,path);
		strcat(filename,"Image_");
		strcat(filename,fnum);
		strcat(filename,"_");
		strcat(filename,type);
		strcat(filename,".bin");
		if((fp=fopen(filename,"rb"))==NULL){
			printf("cannnot open %s\n",filename);
			continue;
		}
		for(ix=0;ix<nx;ix++){
			for(iz=0;iz<nz;iz++){
				fread(&a1,sizeof(float),1,fp);
				input[ix][iz]+=a1;
			}
		}
		fclose(fp);   
		strcpy(filename,path);
		strcat(filename,"Cdipg_");
	 	strcat(filename,fnum);
		strcat(filename,"_");
		strcat(filename,type);
		strcat(filename,".bin");
		if((fp=fopen(filename,"rb"))==NULL){
			printf("cannnot open %s\n",filename);
			continue;
		}
		printf("i_cdipg=%d\n",i);
		
		for(ix=0;ix<nx;ix++){
			for(j=0;j<ncdipg;j++){
			      for(iz=0;iz<nz;iz++){
				      fread(&a2,sizeof(float),1,fp);
				      udp[ix*nz+iz][j]+=a2;
			      }
		      }
		}
	    fclose(fp);//*/
     }
	strcpy(filename,"./Image_gf_ps");
	strcat(filename,".bin");
	fp=fopen(filename,"wb");
	for(ix=0;ix<nx;ix++){
		for(iz=0;iz<nz;iz++){
			a1=input[ix][iz];
			fwrite(&a1,sizeof(float),1,fp);
			input[ix][iz]=0;
		}
	}
	fclose(fp);
	strcpy(filename,"./vf1_g_dip_");
	strcat(filename,type);
	strcat(filename,".bin");
	fp=fopen(filename,"wb");
	for(ix=+0;ix<nx;ix++){
	    for(j=0;j<ncdipg;j++){
	    	for(iz=0;iz<nz;iz++){
		      a2=udp[ix*nz+iz][j];
		      fwrite(&a2,sizeof(float),1,fp);
		      udp[ix*nz+iz][j]=0;
	       }
		}
	}
	fclose(fp);//*/
	exit(0);

}
