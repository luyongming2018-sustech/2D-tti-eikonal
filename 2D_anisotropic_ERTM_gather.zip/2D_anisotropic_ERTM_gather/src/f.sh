for i in `seq 360` 
    do
	 ./ertm2d ishot=$i  igpu=0 path=.. 
    done
