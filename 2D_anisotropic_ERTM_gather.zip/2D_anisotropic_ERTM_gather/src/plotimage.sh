psimage < vf1_g_450_pp.bin hbox=5 wbox=8 label1="Depth (km)" label2="Angle (degree)" d1=0.005 d2=3 f2=-90 n1=501 perc=99.8 >dip_pp.eps 
psimage < vf1_g_450_ps.bin hbox=5 wbox=8 label1="Depth (km)" label2="Angle (degree)" d1=0.005 d2=3 f2=-90 n1=501 perc=99.8 >dip_ps.eps 
psimage < Image_gf_pp.bin hbox=5 wbox=8 label1="Depth (km)" label2="Distance (km)" d1=0.005 d2=0.005  n1=501 perc=99.8 >img_pp.eps 
psimage < Image_gf_ps.bin hbox=5 wbox=8 label1="Depth (km)" label2="Distance (km)" d1=0.005 d2=0.005  n1=501 perc=99.8 >img_ps.eps 
