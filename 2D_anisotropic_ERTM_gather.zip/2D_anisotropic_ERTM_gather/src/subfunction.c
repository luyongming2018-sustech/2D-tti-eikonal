#define pi 3.141592653
#define PI 3.141592653
#define mm 4
#define PI2 PI/2.0

__constant__ float c1[2]={0.0,0.5};
__constant__ float c4[5]={0.0,0.8,-0.2,0.038095,-0.0035714};
__constant__ float stencil[5]={-205.0/72.0,8.0/5.0,-1.0/5.0,8.0/315.0,-1.0/560.0};

//a################################################################################
void check_gpu_error (const char *msg) 
/*< check GPU errors >*/
{
    cudaError_t err = cudaGetLastError ();
    if (cudaSuccess != err) { 
	printf("Cuda error: %s: %s\n", msg, cudaGetErrorString (err)); 
	exit(0);   
    }
}
//a################################################################################
__global__ void add_source(float pfac,float xsn,float zsn,int nx,int nz,int nnx,int nnz,float dt,float t,
                        float favg,int wtype,int npd,int is,int ds,float *P,float *Q, float *wave,int it)
/*< generate ricker wavelet with time deley >*/
{
       int ixs,izs;
       float x_,x2_,tdelay,ts,source=0.0,fs; 
       //int i,j;
  
       tdelay=1.0/favg;
       ts=t-tdelay;
       fs=xsn+(is-1)*ds;

	if(wtype==1)//ricker wavelet
	{
          x_=favg*ts;
          x2_=x_*x_;
          source=(1-2*pi*pi*(x2_))*exp(-(pi*pi*x2_));
	  wave[it]=source;
	}else if(wtype==2){//derivative of gaussian
          x_=(-4)*favg*favg*pi*pi/log(0.1);
          source=(-2)*pi*pi*ts*exp(-x_*ts*ts);
        }else if(wtype==3){//derivative of gaussian
          x_=(-1)*favg*favg*pi*pi/log(0.1);
          source=exp(-x_*ts*ts);
        }

       if(t<=2*tdelay)
       {         
           	ixs = (int)(fs+0.5)+npd-1;
			izs = (int)(zsn+0.5)+npd-1;

			P[(ixs+1)*nnz+(izs+1)]+=sqrt(2.0)*pfac*source;
			Q[(ixs+1)*nnz+(izs+1)]+=sqrt(2.0)*pfac*source;
			P[ixs*nnz+izs]-=sqrt(2.0)*pfac*source;
			Q[ixs*nnz+izs]-=sqrt(2.0)*pfac*source;
			P[(ixs+1)*nnz+izs]+=sqrt(2.0)*pfac*source;
			Q[(ixs+1)*nnz+izs]-=sqrt(2.0)*pfac*source;
			P[ixs*nnz+(izs+1)]-=sqrt(2.0)*pfac*source;
			Q[ixs*nnz+(izs+1)]+=sqrt(2.0)*pfac*source;
          
       }//*/
       
}
/*******************func*********************/ 
void generateWavelet(float pfac,float dt,float favg,float src[],int nt,int wtype)
{
       float x_,x2_,tdelay,ts,source=0.0;  
       int st; 
       tdelay=1.0/favg; 
       st=(int)(2*tdelay/dt)+1;        
        int i;
        for(i=0;i<st;i++){
            ts=i*dt-tdelay;
            if(wtype==1){//ricker wavelet 
                  x_=favg*ts;
                  x2_=x_*x_;
                  source=(1-2*pi*pi*(x2_))*exp(-(pi*pi*x2_));
            }else if(wtype==2){//derivative of gaussian
                        x_=(-4)*favg*favg*pi*pi/log(0.1);
                        source=(-2)*pi*pi*ts*exp(-x_*ts*ts);
                  }else if(wtype==3){//derivative of gaussian
                        x_=(-1)*favg*favg*pi*pi/log(0.1);
                        source=exp(-x_*ts*ts);
                        }
       src[i]=pfac*source; 
       } 
       for(i=st;i<nt;i++) src[i]=0.0; 
}    
/*******************func***********************/
__global__ void VTI_FD(int nx,int nz,int nnx,int nnz,float dt,float dx,float dz,
                           float *P0,float *Q0,float *P1,float *Q1,float *vp,float *vs,int npd,
                           float *delta,float *epsilon,float *theta,int fs,int ds,int zs,int is,bool SV)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int im,ix,iz,imx,imz,rx,rz,R=15,r=4;
      float dttxx,dttzz,dttxz,Pxx,Qzz,Pzz,Qxx,Pxz,Qxz,ee,dd,c11,c13,c33,c44,cc,ss,s2;

      ix=id/nnz;
      iz=id%nnz;

      dttxx=dt*dt/(dx*dx);
      dttzz=dt*dt/(dz*dz);
      dttxz=dt*dt/(dx*dz);

      if(id>=0&&id<nnx*nnz)
      {
/************************i****************************************/
/************************iso circle start*************************/
            rx=ix-(fs+(is-1)*ds+npd);
            rz=iz-(zs+npd);
            if(SV){
                  if((rx*rx+rz*rz)<=R*R){
                        if((rx*rx+rz*rz)<=r*r){
                              ee = 0.0;
                              dd = 0.0;
                        }else{
                              ee = 0.5*(1-cos(pi*((sqrtf(rx*rx+rz*rz)-r)*4.0/(R*3.0-1))))*epsilon[id];
                              dd = 0.5*(1-cos(pi*((sqrtf(rx*rx+rz*rz)-r)*4.0/(R*3.0-1))))*delta[id]; 
                        }
                  }else{
                        ee=epsilon[id];
                        dd=delta[id];
                  }
            }else{
                  ee=epsilon[id];
                  dd=delta[id];
            }
/************************ iso circle end *************************/
/************************i****************************************/
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1))
            {
/************************ Pxx Pzz Qzz Qxx ********************************/
                  Pxx=stencil[0]*P1[id];
                  Pzz=stencil[0]*P1[id];
                  Qzz=stencil[0]*Q1[id];
                  Qxx=stencil[0]*Q1[id];

                  for(im=1;im<=mm;im++)
                  {
                        Pxx+=stencil[im]*(P1[id+im*nnz]+P1[id-im*nnz]);
                        Pzz+=stencil[im]*(P1[id+im]    +P1[id-im]);
                        Qzz+=stencil[im]*(Q1[id+im]    +Q1[id-im]);
                        Qxx+=stencil[im]*(Q1[id+im*nnz]+Q1[id-im*nnz]);
                  }
/************************ Pxz Qxz ********************************/
                  Pxz=0.0;
                  Qxz=0.0; 
                  for(imz=0;imz<=mm;imz++)
                  {
                        for(imx=0;imx<=mm;imx++)
                        {
                              Pxz+=c4[imx]*c4[imz]*(P1[id+imx*nnz+imz]+P1[id-imx*nnz-imz]-P1[id-imx*nnz+imz]-P1[id+imx*nnz-imz]);
                              Qxz+=c4[imx]*c4[imz]*(Q1[id+imx*nnz+imz]+Q1[id-imx*nnz-imz]-Q1[id-imx*nnz+imz]-Q1[id+imx*nnz-imz]);
                        }
                  }
/****a*****************************************************************/
                  Pxx*=dttxx;
                  Pzz*=dttzz;
                  Pxz*=dttxz;
                  Qzz*=dttzz;
                  Qxx*=dttxx;
                  Qxz*=dttxz;
/****a*****************************************************************/
                  cc=cos(theta[id])*cos(theta[id]);
                  ss=sin(theta[id])*sin(theta[id]);
                  s2=sin(theta[id]*2.0);
/****a*****************************************************************/
                  c11=vp[id]*vp[id]*(1+2*ee);
                  c13=vp[id]*vp[id]*(1+2*dd);
                  c33=vp[id]*vp[id];
                  c44=vs[id]*vs[id];
/****a*****************************************************************/
                  P0[id] = 2.0*P1[id] - P0[id]  + c11*(cc*Pxx + ss*Pzz + s2*Pxz)
                                                     + c44*(ss*Pxx + cc*Pzz - s2*Pxz)
                                                     + sqrt((c33-c44)*(c13-c44))*(-0.5*s2*(Qxx-Qzz)+(cc-ss)*Qxz);

                  Q0[id] = 2.0*Q1[id] - Q0[id]  + c44*(cc*Qxx + ss*Qzz + s2*Qxz)
                                                     + c33*(ss*Qxx + cc*Qzz - s2*Qxz)
                                                     + sqrt((c33-c44)*(c13-c44))*(-0.5*s2*(Pxx-Pzz)+(cc-ss)*Pxz);

            }
      }
}                      
/*************func*******************/
void pad_vv(int nx,int nz,int nnx,int nnz,int npd,float *ee)
{
     int ix,iz,id;
 
    for(id=0;id<nnx*nnz;id++)
     {
       ix=id/nnz;
       iz=id%nnz;
       if(ix<npd){
           ee[id]=ee[npd*nnz+iz];  //left
       }else if(ix>=nnx-npd){
           ee[id]=ee[(nnx-npd-1)*nnz+iz];//right
       }
     }
    for(id=0;id<nnx*nnz;id++)
     {
       ix=id/nnz;
       iz=id%nnz;
       if(iz<npd){
           ee[id]=ee[ix*nnz+npd];//up
       }else if(iz>=nnz-npd){
           ee[id]=ee[ix*nnz+nnz-npd-1];//down
       }
       //if(ee[id]==0){printf("ee[%d][%d]==0.0\n",ix,iz);exit(0);}
     }
}
/*************func*******************/
void read_file(char FN1[],char FN2[],char FN3[],char FN4[],int nx,int nz,int nnx,int nnz,float *vv,float *epsilon,float *delta,float *theta, float *vs,int npd)
{
      int i,j,id;
		
      FILE *fp1,*fp2,*fp3,*fp4;
      if((fp1=fopen(FN1,"rb"))==NULL)printf("error open <%s>!\n",FN1);
      if((fp2=fopen(FN2,"rb"))==NULL)printf("error open <%s>!\n",FN2);
      if((fp3=fopen(FN3,"rb"))==NULL)printf("error open <%s>!\n",FN3);
      if((fp4=fopen(FN4,"rb"))==NULL)printf("error open <%s>!\n",FN4);
      for(i=npd;i<nx+npd;i++)
      {
            for(j=npd;j<nz+npd;j++)
            {
                id=i*nnz+j;
				fread(&vv[id],4L,1,fp1);
				//vv[id]=3100;
	
				fread(&epsilon[id],4L,1,fp2);//
				//epsilon[id]=0.0;
				//epsilon[id]=0.3;
				fread(&delta[id],4L,1,fp3);//
				//delta[id]=0.0;
				//delta[id]=0.1;
				fread(&theta[id],4L,1,fp4);//
				theta[id]=theta[id]*pi/180.0;

                 vs[id]=vv[id]/1.5;
                  //vs[id]=sqrt(vv[id]*vv[id]*(epsilon[id]-delta[id])/9);//vs[id]=2000;
            }
      }
      fclose(fp1);
      fclose(fp2);
      fclose(fp3);
      fclose(fp4);
}
/*************func*******************/
void rec_amprick_remove(float *datax,int nt,int nrv,float src[],float dt)
{
	double a,b,f1,f2,f3,d1,c1,c18,c12,t12,m,a1,n1;
	long i,it,iw,ntfft,nw,fmax_n;
	double fmax_vlu,fmax_vlu1,aver,dw;
	float *wl,*wnd,*amprick;
	complex *wlsp;
	FILE *fp;
	ntfft=npfar(nt);
	nw=ntfft/2+1;
	wl=(float*)calloc(ntfft,sizeof(float));
	wlsp=(complex*)calloc(nw,sizeof(complex));
	wnd=(float*)calloc(nw,sizeof(float));
	amprick=(float*)calloc(nw,sizeof(float));

	for(it=0;it<nt;it++){
		wl[it]=src[it];
	}
	pfarc(1,ntfft,wl,wlsp);
	dw=2*PI/(dt*ntfft);

	printf("nrv=%ld\n",nrv);

	for(iw=0;iw<nw;iw++){
		f1=wlsp[iw].r;
		f2=wlsp[iw].i;
		amprick[iw]=sqrt(wlsp[iw].r*wlsp[iw].r+wlsp[iw].i*wlsp[iw].i)*pow(iw*dw,1);
		amprick[iw]=pow(amprick[iw],1);
	}

	fp=fopen("amprick","wb");
	fwrite(amprick,sizeof(float),nw,fp);
	fclose(fp);

	fmax_n=0;
	fmax_vlu1=0.0;
	for(iw=0;iw<nw;iw++){
		if(amprick[iw]>fmax_vlu1){
			fmax_vlu1=amprick[iw];
			fmax_n=iw;
		}
	}
	printf("nw,fmax_n=%d,%d\n",nw,fmax_n);
	aver=0.0;
	for(iw=0;iw<=3*fmax_n;iw++){
		aver+=amprick[iw];
	}
	aver=aver/(3*fmax_n+1)/1.0;
	f1=0.4*fmax_n/2.0;
	f2=2.5*fmax_n;
	f2=(int)f2+1;
	f3=2.8*fmax_n;
	f3=(int)f3+1;
	for(iw=0;iw<nw;iw++){
		wnd[iw]=1.0;
	}
	for(iw=0;iw<=f1;iw++){
		wnd[iw]=0.42-0.5*cos(2*PI*iw/(2*f1))+0.08*cos(4*PI*iw/(2*f1));
	}	
	for(iw=f2;iw<=f3;iw++){
		wnd[iw]=0.42-0.5*cos(2*PI*(iw+f3-2*f2)/(f3-f2)/2)+0.08*cos(4*PI*(iw+f3-2*f2)/(f3-f2)/2);
	}
	for(iw=f3+1;iw<nw;iw++){
		wnd[iw]=0.0;
	}
	c1=aver*0.05;
	c18=0.9*c1;
	c12=1.0/c1;

	for(i=0;i<nrv;i++){
		for(it=0;it<nt;it++){
			//wl[it]=datax[it*nrv+i];
			wl[it]=datax[i*nt+it];
		}
		for(it=0.9*nt;it<nt;it++){
			a1=it-0.9*nt;
			a1=cos(PI/2.0*a1/(nt-0.9*nt));
			wl[it]*=a1;				
		}
		for(it=nt;it<ntfft;it++){
			wl[it]=0;
		}
		for(iw=0;iw<nw;iw++){
			wlsp[iw].r=0;
			wlsp[iw].i=0;			
		}
		pfarc(1,ntfft,wl,wlsp);
		for(iw=0;iw<=3*fmax_n;iw++){
			if(amprick[iw]>c18){
				wlsp[iw].r=wlsp[iw].r/amprick[iw]*wnd[iw]*iw*dw;
				wlsp[iw].i=wlsp[iw].i/amprick[iw]*wnd[iw]*iw*dw;				
			}
			else{
				t12=amprick[iw]-c1;
				d1=t12*c12;
		              	m=(1-d1+d1*d1)*c12;
				wlsp[iw].r=wlsp[iw].r*m*wnd[iw]*iw*dw;
				wlsp[iw].i=wlsp[iw].i*m*wnd[iw]*iw*dw;
			}
		}

		for(iw=0;iw<=3*fmax_n;iw++){
			f1=wlsp[iw].r*fmax_vlu1;
			f2=wlsp[iw].i*fmax_vlu1;
			wlsp[iw].r=pow(iw*dw,0.5)*(f1+f2);
			wlsp[iw].i=pow(iw*dw,0.5)*(f2-f1);
		}

		
		for(iw=3*fmax_n+1;iw<nw;iw++){
			wlsp[iw].r=0;
			wlsp[iw].i=0;
		}
		pfacr(-1,ntfft,wlsp,wl);
		
		for(it=0;it<nt;it++){
			wl[it]=wl[it]/ntfft;
		}
		for(it=0;it<nt;it++){
			//datax[it*nrv+i]=wl[it];
			datax[i*nt+it]=wl[it];
		}
	}
}
/*************func*******************/
__global__ void rece_zero(int nnx, int nnz, int nx, int nz, int npd, float *P0)
{		
      int id=threadIdx.x+blockDim.x*blockIdx.x;

      if(id<nx){
          P0[npd+nnz*(id+npd)]=0;
      }       
}
__global__ void shot_record(int nnx, int nnz, int nx, int nz, int npd, int it, int nt, float *P0, float *shot, bool flag)
{		
      int id=threadIdx.x+blockDim.x*blockIdx.x;

      if(id<nx){
            if(flag){
                  shot[it+nt*id]=P0[npd+nnz*(id+npd)];}
            else{
                  P0[npd+nnz*(id+npd)]=shot[it+nt*id];}
            }       
}
/*************func**************/  
__global__ void mute_directwave(int nx,int nt,float dt,float favg,
                     float dx,float dz,int fs,int ds,int zs,int is,
                     float *vp,float *epsilon,float *shot,int tt)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;

      int mu_t,mu_nt;
      float mu_x,mu_z,mu_t0;

      int ix,it;

      if(id<(nx*nt))
      {     
            ix=id/nt;
            it=id%nt;
            mu_x=dx*abs(ix-fs-(is-1)*ds);
            mu_z=dz*zs;
            mu_t0=sqrtf(pow(mu_x,2)+pow(mu_z,2))/(vp[1]*sqrtf(1+2*epsilon[1]));
            mu_t=(int)(2.0/(dt*favg));
            mu_nt=(int)(mu_t0/dt)+mu_t+tt;
            if(it<mu_nt) shot[id]=0.0;
                  
            ix=(id+nx*nt/2)/nt;
            it=(id+nx*nt/2)%nt;
            mu_x=dx*abs(ix-fs-(is-1)*ds);
            mu_z=dz*zs;
            mu_t0=sqrtf(pow(mu_x,2)+pow(mu_z,2))/(vp[1]*sqrtf(1+2*epsilon[1]));
            mu_t=(int)(2.0/(dt*favg));
            mu_nt=(int)(mu_t0/dt)+mu_t+tt;
            if(it<mu_nt) shot[id+nx*nt/2]=0.0;
      }
}
/************************************func***************************************/      
__global__ void absorb_bndr(float *P0,float *P1,float *Q0,float *Q1,int nx,int nz,int nnz,int npd,float qp) 
{
    int id=threadIdx.x+blockDim.x*blockIdx.x;
    int ix,iz;

        ix=id/nnz;
        iz=id%nnz;

   if(id<(nx+2*npd)*nnz-1)
   {
         if(ix<npd){
               P0[id]*=( qp*pow((npd-ix)/(1.0*npd),2) + 1 );
               P1[id]*=( qp*pow((npd-ix)/(1.0*npd),2) + 1 );
               Q0[id]*=( qp*pow((npd-ix)/(1.0*npd),2) + 1 );
               Q1[id]*=( qp*pow((npd-ix)/(1.0*npd),2) + 1 );
         }else if(ix>=nx+npd){
               P0[id]*=( qp*pow((ix-npd-nx)/(1.0*npd),2) + 1 );
               P1[id]*=( qp*pow((ix-npd-nx)/(1.0*npd),2) + 1 );
               Q0[id]*=( qp*pow((ix-npd-nx)/(1.0*npd),2) + 1 );
               Q1[id]*=( qp*pow((ix-npd-nx)/(1.0*npd),2) + 1 );
         }if(iz<npd){
               P0[id]*=( qp*pow((npd-iz)/(1.0*npd),2) + 1 );
               P1[id]*=( qp*pow((npd-iz)/(1.0*npd),2) + 1 );
               Q0[id]*=( qp*pow((npd-iz)/(1.0*npd),2) + 1 );
               Q1[id]*=( qp*pow((npd-iz)/(1.0*npd),2) + 1 );
         }else if(iz>=nz+npd){
               P0[id]*=( qp*pow((iz-npd-nz)/(1.0*npd),2) + 1 );
               P1[id]*=( qp*pow((iz-npd-nz)/(1.0*npd),2) + 1 );
               Q0[id]*=( qp*pow((iz-npd-nz)/(1.0*npd),2) + 1 );
               Q1[id]*=( qp*pow((iz-npd-nz)/(1.0*npd),2) + 1 );
         }
    }
} 
/************************************func***************************************/ 
void write_file(char FN[], int nx, int nz, int npd, float *e)
{
      int i,j,id;
		
      FILE *fp1;
      if((fp1=fopen(FN,"wb"))==NULL)printf("error open <%s>!\n",FN);
      for(i=npd;i<nx+npd;i++)
      {
            for(j=npd;j<nz+npd;j++)
            {
                  id=i*(nz+2*npd)+j;
                  fwrite(&e[id],4L,1,fp1);
            }
      }
      fclose(fp1);
}
/************************************func***************************************/ 
__global__ void normal_stress(int nnx, int nnz, float dx, float dz, float *P1, float *Q1, float *vp, float *vs,float *tau)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
      float vx,vz;
      float buffer1,buffer2,buffer3,buffer4;
      float txx,tzz,txz;
      ix=id/nnz;
      iz=id%nnz;
      
      if(id>=0&&id<nnx*nnz){
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
                  buffer1=( 0.8*(P1[id+nnz]-P1[id-nnz]) - 0.2*(P1[id+2*nnz]-P1[id-2*nnz]) + 0.0381*(P1[id+3*nnz]-P1[id-3*nnz]) - 0.0036*(P1[id+4*nnz]-P1[id-4*nnz]) )/dx;
                  buffer2=( 0.8*(Q1[id+nnz]-Q1[id-nnz]) - 0.2*(Q1[id+2*nnz]-Q1[id-2*nnz]) + 0.0381*(Q1[id+3*nnz]-Q1[id-3*nnz]) - 0.0036*(Q1[id+4*nnz]-Q1[id-4*nnz]) )/dx;
                  buffer3=( 0.8*(P1[id+1]-P1[id-1]) - 0.2*(P1[id+2]-P1[id-2]) + 0.0381*(P1[id+3]-P1[id-3]) - 0.0036*(P1[id+4]-P1[id-4]) )/dz;
                  buffer4=( 0.8*(Q1[id+1]-Q1[id-1]) - 0.2*(Q1[id+2]-Q1[id-2]) + 0.0381*(Q1[id+3]-Q1[id-3]) - 0.0036*(Q1[id+4]-Q1[id-4]) )/dz;
                  txx=vp[id]*vp[id]*buffer1+(vp[id]*vp[id]-vs[id]*vs[id])*buffer4;
                  tzz=(vp[id]*vp[id]-vs[id]*vs[id])*buffer1+vp[id]*vp[id]*buffer4;
			tau[id]=txx+tzz;
            }
      } 
}
/************************************func***************************************/ 
__global__ void space_time_derivative(int nnx, int nnz, float *u0, float *u1, float *fx, float *fz, float *ft)
{
	int id=threadIdx.x+blockDim.x*blockIdx.x;
	int ix,iz;
      ix=id/nnz;
      iz=id%nnz;
	if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
		fx[id] = (-u0[id-nnz]+u0[id]-u0[id-nnz+1]+u0[id+1])/4+(-u1[id-nnz]+u1[id]-u1[id-nnz+1]+u1[id+1])/4;
		fz[id] = (-u0[id-nnz]-u0[id]+u0[id-nnz+1]+u0[id+1])/4+(-u1[id-nnz]-u1[id]+u1[id-nnz+1]+u1[id+1])/4;
		ft[id] = ( u0[id-nnz]+u0[id]+u0[id-nnz+1]+u0[id+1])/4-( u1[id-nnz]+u1[id]+u1[id-nnz+1]+u1[id+1])/4;
	}
}
/************************************func***************************************/ 
__global__ void space_time_derivative2(int nnx, int nnz, float dt, float dx, float dz, float *P, float *P0, float *fx, float *fz, float *ft)
{
	int id=threadIdx.x+blockDim.x*blockIdx.x;
	int ix,iz;
	float Px, Pz, Pt;
      ix=id/nnz;
      iz=id%nnz;	
	if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
		Pt=(P0[id]-P[id])/dt;
		Px=( 0.8*(P[id+nnz]-P[id-nnz]) - 0.2*(P[id+2*nnz]-P[id-2*nnz]) + 0.0381*(P[id+3*nnz]-P[id-3*nnz]) - 0.0036*(P[id+4*nnz]-P[id-4*nnz]) )/dx;
		Pz=( 0.8*(P[id+1]-P[id-1]) - 0.2*(P[id+2]-P[id-2]) + 0.0381*(P[id+3]-P[id-3]) - 0.0036*(P[id+4]-P[id-4]) )/dz;
		fx[id] = Px;
		fz[id] = Pz;
		ft[id] = Pt;
	}
}
/************************************func***************************************/ 
__global__ void calculat_field(int nnx, int nnz, float *u, float *v, float *wf)
{
	int id=threadIdx.x+blockDim.x*blockIdx.x;
	int ix,iz;
      ix=id/nnz;
      iz=id%nnz;
	float uAvg, vAvg, item;
	if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
		wf[id] = u[id]*u[id]+v[id]*v[id];
	}
}
/************************************func***************************************/ 
__global__ void single_hs(int nnx, int nnz, float *u0, float *v0, float alpha, float *fx, float *fz, float *ft, float *u, float *v)
{
	int id=threadIdx.x+blockDim.x*blockIdx.x;
	int ix,iz;
      ix=id/nnz;
      iz=id%nnz;
	float uAvg, vAvg, item;
	if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
		uAvg = (u0[id-nnz-1]+u0[id-nnz+1]+u0[id+nnz-1]+u0[id+nnz+1])/12+(u0[id-nnz]+u0[id+nnz]+u0[id-1]+u0[id+1])/6;
		vAvg = (v0[id-nnz-1]+v0[id-nnz+1]+v0[id+nnz-1]+v0[id+nnz+1])/12+(v0[id-nnz]+v0[id+nnz]+v0[id-1]+v0[id+1])/6;
		item = (fx[id]*uAvg+fz[id]*vAvg+ft[id])/(alpha*alpha+fx[id]*fx[id]+fz[id]*fz[id]);
		u[id] = uAvg - fx[id]*item;
		v[id] = vAvg - fz[id]*item;
		//u[id] = -fx[id]*ft[id];
		//v[id] = -fz[id]*ft[id];
	}
}
/************************************func***************************************/ 
__global__ void exchange(int nnx, int nnz, float *uflux, float *ufluz, float *flux, float *fluz)
{
	int id=threadIdx.x+blockDim.x*blockIdx.x;
	if(id<nnx*nnz){
		uflux[id] = flux[id];
		ufluz[id] = fluz[id];
	}
}

/************************************func***************************************/ 
__global__ void Poynting(int nnx, int nnz, float dt, float dx, float dz,float *P0, float *Q0, float *P1, float *Q1, float *vp, float *vs, float *flux, float *fluz)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
      float vx,vz;
      float buffer1,buffer2,buffer3,buffer4;
      float txx,tzz,txz;
      ix=id/nnz;
      iz=id%nnz;
      
      if(id>=0&&id<nnx*nnz){
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
                  vx=-(P1[id]-P0[id])/dt;
                  vz=-(Q1[id]-Q0[id])/dt;
                  buffer1=( 0.8*(P1[id+nnz]-P1[id-nnz]) - 0.2*(P1[id+2*nnz]-P1[id-2*nnz]) + 0.0381*(P1[id+3*nnz]-P1[id-3*nnz]) - 0.0036*(P1[id+4*nnz]-P1[id-4*nnz]) )/dx;
                  buffer2=( 0.8*(Q1[id+nnz]-Q1[id-nnz]) - 0.2*(Q1[id+2*nnz]-Q1[id-2*nnz]) + 0.0381*(Q1[id+3*nnz]-Q1[id-3*nnz]) - 0.0036*(Q1[id+4*nnz]-Q1[id-4*nnz]) )/dx;
                  buffer3=( 0.8*(P1[id+1]-P1[id-1]) - 0.2*(P1[id+2]-P1[id-2]) + 0.0381*(P1[id+3]-P1[id-3]) - 0.0036*(P1[id+4]-P1[id-4]) )/dz;
                  buffer4=( 0.8*(Q1[id+1]-Q1[id-1]) - 0.2*(Q1[id+2]-Q1[id-2]) + 0.0381*(Q1[id+3]-Q1[id-3]) - 0.0036*(Q1[id+4]-Q1[id-4]) )/dz;
                  txx=vp[id]*vp[id]*buffer1+(vp[id]*vp[id]-vs[id]*vs[id])*buffer4;
                  tzz=(vp[id]*vp[id]-vs[id]*vs[id])*buffer1+vp[id]*vp[id]*buffer4;
                  txz=vs[id]*vs[id]*(buffer2+buffer3);
                  flux[id]=vx*txx+vz*txz;
                  fluz[id]=vx*txz+vz*tzz;
            }
      } 
}
/************************************func***************************************/ 
__global__ void phase_poynting(int nnx, int nnz, float dt, float dx, float dz, float *P, float *P0, float *flux, float *fluz)
{
	int id=threadIdx.x+blockDim.x*blockIdx.x;
	int ix,iz;
	float Px, Pz, Pt;
      ix=id/nnz;
      iz=id%nnz;	
	if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
		Pt=(P0[id]-P[id])/dt;
		Px=( 0.8*(P[id+nnz]-P[id-nnz]) - 0.2*(P[id+2*nnz]-P[id-2*nnz]) + 0.0381*(P[id+3*nnz]-P[id-3*nnz]) - 0.0036*(P[id+4*nnz]-P[id-4*nnz]) )/dx;
		Pz=( 0.8*(P[id+1]-P[id-1]) - 0.2*(P[id+2]-P[id-2]) + 0.0381*(P[id+3]-P[id-3]) - 0.0036*(P[id+4]-P[id-4]) )/dz;
		flux[id]=-Px*Pt;
		fluz[id]=-Pz*Pt;
	}
}
/************************************func***************************************/ 
__global__ void ls_poynting(int nnx, int nnz, float *flux, float *fluz, float *uflux, float *ufluz)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
      float buffer;
      ix=id/nnz;
      iz=id%nnz;           
      if(id>=0&&id<nnx*nnz){
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
/*
			buffer =flux[id-2*nnz-2]+flux[id-2*nnz-1]+flux[id-2*nnz]+flux[id-2*nnz+1]+flux[id-2*nnz+2];
			buffer+=flux[id-1*nnz-2]+flux[id-1*nnz-1]+flux[id-1*nnz]+flux[id-1*nnz+1]+flux[id-1*nnz+2];
			buffer+=flux[id-0*nnz-2]+flux[id-0*nnz-1]+flux[id-0*nnz]+flux[id-0*nnz+1]+flux[id-0*nnz+2];
			buffer+=flux[id+1*nnz-2]+flux[id+1*nnz-1]+flux[id+1*nnz]+flux[id+1*nnz+1]+flux[id+1*nnz+2];
			buffer+=flux[id+2*nnz-2]+flux[id+2*nnz-1]+flux[id+2*nnz]+flux[id+2*nnz+1]+flux[id+2*nnz+2];
			buffer/=25;
			uflux[id]=buffer;

			buffer =fluz[id-2*nnz-2]+fluz[id-2*nnz-1]+fluz[id-2*nnz]+fluz[id-2*nnz+1]+fluz[id-2*nnz+2];
			buffer+=fluz[id-1*nnz-2]+fluz[id-1*nnz-1]+fluz[id-1*nnz]+fluz[id-1*nnz+1]+fluz[id-1*nnz+2];
			buffer+=fluz[id-0*nnz-2]+fluz[id-0*nnz-1]+fluz[id-0*nnz]+fluz[id-0*nnz+1]+fluz[id-0*nnz+2];
			buffer+=fluz[id+1*nnz-2]+fluz[id+1*nnz-1]+fluz[id+1*nnz]+fluz[id+1*nnz+1]+fluz[id+1*nnz+2];
			buffer+=fluz[id+2*nnz-2]+fluz[id+2*nnz-1]+fluz[id+2*nnz]+fluz[id+2*nnz+1]+fluz[id+2*nnz+2];
			buffer/=25;
			ufluz[id]=buffer;
*/			

                  buffer=flux[id-nnz-1]+flux[id-nnz]+flux[id-nnz+1]+flux[id-1]+flux[id]+flux[id+1]+flux[id+nnz-1]+flux[id+nnz]+flux[id+nnz+1];
                  buffer/=9;
                  uflux[id]=buffer;
                  buffer=fluz[id-nnz-1]+fluz[id-nnz]+fluz[id-nnz+1]+fluz[id-1]+fluz[id]+fluz[id+1]+fluz[id+nnz-1]+fluz[id+nnz]+fluz[id+nnz+1];
                  buffer/=9;
                  ufluz[id]=buffer;

            }
      } 
}
/************************************func***************************************/  
__global__ void normalize(int nnx, int nnz, float *uflux, float *ufluz, float *ang)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
      float buffer,buffer0,buffer1;
	float sign;
      ix=id/nnz;
      iz=id%nnz;           
	if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
		buffer =sqrt(uflux[id]*uflux[id]+ufluz[id]*ufluz[id])+1.e-21;
		buffer0=uflux[id]/buffer;
		buffer1=ufluz[id]/buffer;
		uflux[id]=buffer0;
		ufluz[id]=buffer1;
		buffer =sqrt(buffer0*buffer0+buffer1*buffer1)+1.e-21;
		sign = (buffer0<0?-1:1);
		ang[id]=sign*acosf(buffer1/buffer);		
	}
}
__global__ void normalize1(int nnx, int nnz, float *uflux, float *ufluz, float *flux, float *fluz)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
      float buffer;
      ix=id/nnz;
      iz=id%nnz;           
      if(id>=0&&id<nnx*nnz){
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
                  buffer=sqrt(uflux[id]*uflux[id]+ufluz[id]*ufluz[id]);
                  if(buffer>1e-5){
                        flux[id]=uflux[id]/buffer;
                        fluz[id]=ufluz[id]/buffer;
                  }else{
                        flux[id]=0;
                        fluz[id]=0;
                  }
            }
      } 
}
//-------------------------------------------------------------------------------------------------------------------------
__global__ void wave_seperate_zh(int nnx, int nnz, float *P1, float *Q1, float dx, float dz, float *ang, float *up, float *us)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
      float P_x,P_z,Q_x,Q_z;
      ix=id/nnz;
      iz=id%nnz;           
      if(id>=0&&id<nnx*nnz){
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
                  P_x=( 0.8*(P1[id+nnz]-P1[id-nnz]) - 0.2*(P1[id+2*nnz]-P1[id-2*nnz]) + 0.0381*(P1[id+3*nnz]-P1[id-3*nnz]) - 0.0036*(P1[id+4*nnz]-P1[id-4*nnz]) )/dx;
                  Q_x=( 0.8*(Q1[id+nnz]-Q1[id-nnz]) - 0.2*(Q1[id+2*nnz]-Q1[id-2*nnz]) + 0.0381*(Q1[id+3*nnz]-Q1[id-3*nnz]) - 0.0036*(Q1[id+4*nnz]-Q1[id-4*nnz]) )/dx;
                  P_z=( 0.8*(P1[id+1]-P1[id-1]) - 0.2*(P1[id+2]-P1[id-2]) + 0.0381*(P1[id+3]-P1[id-3]) - 0.0036*(P1[id+4]-P1[id-4]) )/dz;
                  Q_z=( 0.8*(Q1[id+1]-Q1[id-1]) - 0.2*(Q1[id+2]-Q1[id-2]) + 0.0381*(Q1[id+3]-Q1[id-3]) - 0.0036*(Q1[id+4]-Q1[id-4]) )/dz;
                  
                  up[id]= cos(ang[id])*P_x + sin(ang[id])*P_z + cos(ang[id])*Q_z - sin(ang[id])*Q_x;
                  us[id]= cos(ang[id])*P_z - sin(ang[id])*P_x - cos(ang[id])*Q_x - sin(ang[id])*Q_z;
            }
      }  
} 
/************************************func***************************************/
__global__ void phase_2_polar(int nnx, int nnz, float *ang0, float *epsil1, float *delta1, float *vp1, float *vs1, float *tilt1, float *ang){
	int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
	ix=id/nnz;
      iz=id%nnz; 
	float epsil,delta,vp,vs,angle0,angle;
	float c11,f,c13,c33,c44;
	float nx,nz,tmp1,tmp2,G11,G33,G13;
	float p_qpx,p_qpz;
	float sign, sign0;
	if(id<nnx*nnz){
		vp=vp1[id];
		vs=vs1[id];
		epsil=epsil1[id];
		delta=delta1[id];
		
  		c11=(1+2*epsil)*vp*vp;
		f=1-vs*vs/(vp*vp);
		c13=vp*vp*sqrt(f*(f+delta))-vs*vs;
		c33=vp*vp;
		c44=vs*vs;
		angle0=ang0[id]+tilt1[id];
		if(angle0>PI)
			angle0=angle0-2*pi;
		if(angle<-PI)
			angle0=2*pi+angle0;
		if(angle0>PI2){
			angle0=pi-angle0;	
			nz=cos(angle0);
    			nx=sin(angle0);
    			tmp1=(c13+c44)*nx*nz;
    			tmp2=(c11-c44)*nx*nx-(c33-c44)*nz*nz;
    			G11= 0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    			G33=-0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    			G13=tmp1;
        		p_qpx=sqrt(G33/(G11+G33));
			if(G13==0){
				sign=0;
			}else if(G13<0){
				sign=-1;
			}else{
				sign=1;
			}
        		p_qpz=sign*sqrt(G11/(G11+G33))+1.e-20;
        		angle=atan(p_qpx/p_qpz);
			angle=pi-angle;
		}else if(angle0<-PI2){
			angle0=pi+angle0;
			nz=cos(angle0);
    			nx=sin(angle0);
    			tmp1=(c13+c44)*nx*nz;
    			tmp2=(c11-c44)*nx*nx-(c33-c44)*nz*nz;
    			G11= 0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    			G33=-0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    			G13=tmp1;
        		p_qpx=sqrt(G33/(G11+G33));
			sign=(G13>0?1:-1);
        		p_qpz=sign*sqrt(G11/(G11+G33))+1.e-20;
        		angle=atan(p_qpx/p_qpz);
    			angle=angle-pi;
		}else{
			nz=cos(angle0);
    			nx=sin(angle0);
    			tmp1=(c13+c44)*nx*nz;
    			tmp2=(c11-c44)*nx*nx-(c33-c44)*nz*nz;
    			G11= 0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    			G33=-0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    			G13=tmp1;
        		p_qpx=sqrt(G33/(G11+G33));
			sign=(G13>0?1:-1);
        		p_qpz=sign*sqrt(G11/(G11+G33))+1.e-20;
        		angle=atan(p_qpx/p_qpz);
		}
		if(angle>PI){
			angle=angle-2*PI;
		}
		if(angle<-PI){
			angle=2*PI+angle;
		}
		ang[id] = angle;
	}
}
/************************************func***************************************/
__global__ void phase_polar(int nnx, int nnz,float *epsilon1,float *delta1,float *vp1,float *vs1,
            float *ang,float *tilt,float *ang0)
{
	int i=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
	ix=i/nnz;
      iz=i%nnz; 
	float angle,ag1,sign,sign0;
	float delta,epsilon,vp,vs,f;
	//double pi=3.1415926535898;
	float c11,c13,c33,c44;
	float nz,nx,tmp1,tmp2,G11,G33,G13;
	float p_qpx,p_qpz;
 
	if(i<nnx*nnz){

		epsilon=epsilon1[i];
		delta=delta1[i];
		vp=vp1[i];
		vs=vs1[i];
		c11=(1+2*epsilon)*vp*vp;
		f=1-vs*vs/(vp*vp);
		c13=vp*vp*sqrt(f*(f+delta))-vs*vs;
		c33=vp*vp;
		c44=vs*vs;
	
		angle=ang[i];
	
		ag1=tilt[i];
		angle+=ag1;
		if(angle>PI){
			angle=angle-2*PI;
		}else if(angle<-PI){
			angle=2*PI+angle;
		}

		if(angle>pi/2){
			angle=pi-angle;
			nz=cos(angle);
			nx=sin(angle);
			tmp1=(c13+c44)*nx*nz;
			tmp2=(c11-c44)*nx*nx-(c33-c44)*nz*nz;
			G11= 0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    			G33=-0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    			G13=tmp1;
			sign0=G13>0?1:-1;
			p_qpx=sqrt(G33/(G11+G33));
        		p_qpz=sign0*sqrt(G11/(G11+G33));
        		angle=atan(p_qpx/p_qpz);
			angle=pi-angle;
		}else if(angle<=-pi/2)
			{
				angle=angle+pi;
				nz=cos(angle);
				nx=sin(angle);
				tmp1=(c13+c44)*nx*nz;
				tmp2=(c11-c44)*nx*nx-(c33-c44)*nz*nz;
				G11= 0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    				G33=-0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    				G13=tmp1;
				sign0=G13>0?1:-1;
				p_qpx=sqrt(G33/(G11+G33));
        			p_qpz=sign0*sqrt(G11/(G11+G33));
        			angle=atan(p_qpx/p_qpz);
				angle=angle-pi;
			}
			else{
				nz=cos(angle);
				nx=sin(angle);
				tmp1=(c13+c44)*nx*nz;
				tmp2=(c11-c44)*nx*nx-(c33-c44)*nz*nz;
				G11= 0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    				G33=-0.5*tmp2-0.5*sqrt(tmp2*tmp2+4*tmp1*tmp1);
    				G13=tmp1;
				sign0=G13>0?1:-1;
				p_qpx=sqrt(G33/(G11+G33));
        			p_qpz=sign0*sqrt(G11/(G11+G33));
        			angle=atan(p_qpx/p_qpz);
			}
		//angle-=ag1;

		if(angle<-PI){
			angle=2*PI+angle;
		}else if(angle>PI){
			angle=angle-2*PI;
		}

		ang0[i]=angle;	
	}	
}
/************************************func***************************************/
__global__ void wave_seperate_final(int nnx,int nnz,float dx,float dz,float *ang,float *P1,float *Q1,float *up,float *us)
{
	int id=threadIdx.x+blockDim.x*blockIdx.x;
	float a,b;
      int ix,iz;
      float P_x,P_z,Q_x,Q_z;
      ix=id/nnz;
      iz=id%nnz;           
      if(id>=0&&id<nnx*nnz){
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
                  P_x=( 0.8*(P1[id+nnz]-P1[id-nnz]) - 0.2*(P1[id+2*nnz]-P1[id-2*nnz]) + 0.0381*(P1[id+3*nnz]-P1[id-3*nnz]) - 0.0036*(P1[id+4*nnz]-P1[id-4*nnz]) )/dx;
                  Q_x=( 0.8*(Q1[id+nnz]-Q1[id-nnz]) - 0.2*(Q1[id+2*nnz]-Q1[id-2*nnz]) + 0.0381*(Q1[id+3*nnz]-Q1[id-3*nnz]) - 0.0036*(Q1[id+4*nnz]-Q1[id-4*nnz]) )/dx;
                  P_z=( 0.8*(P1[id+1]-P1[id-1]) - 0.2*(P1[id+2]-P1[id-2]) + 0.0381*(P1[id+3]-P1[id-3]) - 0.0036*(P1[id+4]-P1[id-4]) )/dz;
                  Q_z=( 0.8*(Q1[id+1]-Q1[id-1]) - 0.2*(Q1[id+2]-Q1[id-2]) + 0.0381*(Q1[id+3]-Q1[id-3]) - 0.0036*(Q1[id+4]-Q1[id-4]) )/dz;
                  a=cos(ang[id]);
			b=sin(ang[id]);
                  up[id]= a*P_x + b*P_z + a*Q_z - b*Q_x;
                  us[id]= a*P_z - b*P_x - a*Q_x - b*Q_z;
            }
      }  
}
/************************************func***************************************/  
__global__ void wave_seperate(int nnx, int nnz, float *P1, float *Q1, float *ang, float *up, float *us)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
      ix=id/nnz;
      iz=id%nnz;  
	float r = 1.e-15;         
      if(id>=0&&id<nnx*nnz){
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
                  up[id]= P1[id]*sin(ang[id])+Q1[id]*cos(ang[id]);
                  us[id]=-P1[id]*cos(ang[id])+Q1[id]*sin(ang[id]);
            }
            //if((abs(up[id])/(abs(us[id])+r))>=10) up[id]=0;
            //if((abs(us[id])/(abs(up[id])+r))>=10) us[id]=0;
      }  
}
/************************************func***************************************/
__global__ void imaging0(int nnx, int nnz, float *up, float *up1, float *us, float *us1,float *uflux,float *uflux1,float *ufluz,float *ufluz1,float *upp,float *ups,float *rps)
{
      int i=threadIdx.x+blockDim.x*blockIdx.x;
	float tmp,tmp1,tmp2,tmp3,tmp4,plr;
	float tmp11,tmp21;

      if(i<nnx*nnz){
            tmp1=uflux[i];
		tmp2=uflux1[i];
		tmp3=ufluz[i];
		tmp4=ufluz1[i];
		tmp=tmp1*tmp2+tmp3*tmp4;

		tmp=tmp1*tmp4-tmp2*tmp3;
		plr=1;
		if(tmp<0){plr=-1;}
		tmp11=tmp1-tmp2;
		tmp21=tmp3-tmp4;

		tmp=1;
		if(tmp21<0){tmp=-1;}

		upp[i]+=up[i]*up1[i]*tmp;

		tmp11=tmp1-tmp2*rps[i];
		tmp21=tmp3-tmp4*rps[i];

		tmp=1;
		if(tmp21<0){tmp=-1;}

		ups[i]+=up[i]*us1[i]*plr*tmp;
    }
}
/************************************func***************************************/
__global__ void imaging(int nnx, int nnz, float *up, float *up1, float *us, float *us1,float *uflux,float *uflux1,float *ufluz,float *ufluz1,float *upp,float *ups,float *rps)
{
      int i=threadIdx.x+blockDim.x*blockIdx.x;
	float tmp,tmp1,tmp2,tmp3,tmp4,plr;
	float tmp11,tmp21;

      if(i<nnx*nnz){
            tmp1=uflux[i];
		tmp2=uflux1[i];
		tmp3=ufluz[i];
		tmp4=ufluz1[i];
		tmp=tmp1*tmp2+tmp3*tmp4;

		if(tmp<0){
			tmp=tmp1*tmp4-tmp2*tmp3;
			plr=1;
			if(tmp<0){plr=-1;}
			tmp11=tmp1-tmp2;
			tmp21=tmp3-tmp4;

			tmp=1;
			if(tmp21<0){tmp=-1;}

			upp[i]-=up[i]*up1[i]*tmp;

			tmp11=tmp1-tmp2*rps[i];
			tmp21=tmp3-tmp4*rps[i];

			tmp=1;
			if(tmp21<0){tmp=-1;}

			ups[i]-=up[i]*us1[i]*plr*tmp;
		}
    }
}
/************************************func***************************************/ 

void aver_get(float flux[],float fluz[],long nno,long nin,float *aver)
{

	int i;
	(*aver)=0;
	for(i=nno;i<nin+nno;i++){	
		(*aver)+=fabs(flux[i])+fabs(fluz[i]);
	}
	(*aver)/=nin*100;
}
void ang_get1(float flux[],float fluz[],float ang[],long nno,long nin1,float aver)
{
	long i;
	double tmp,tmp1,tmp2;
	for(i=nno;i<nin1;i++){
		tmp1=-fluz[i];
		tmp2=flux[i];
		if(fabs(tmp1)>aver||fabs(tmp2)>aver){
			tmp=acos(tmp1/sqrt(tmp1*tmp1+tmp2*tmp2));	
			if(tmp2>=0){
				tmp*=-1;
			}
			//checkflag[i]=0;
		}else{
			tmp=PI;
			//checkflag[i]=-1;
		}	
		ang[i]=tmp;	
	}
}
void ang_get(float flux[],float fluz[],float ang[],long nno,long nin1,float aver)
{
	long i;
	double tmp,tmp1,tmp2;	
	for(i=nno;i<nin1;i++){
		tmp1=fluz[i];
		tmp2=flux[i];
		if(fabs(tmp1)>aver||fabs(tmp2)>aver){
			tmp=acos(tmp1/sqrt(tmp1*tmp1+tmp2*tmp2));	
			if(tmp2<0){
				tmp*=-1;
			}
			//checkflag[i]=0;
		}else{
			tmp=0;
			//checkflag[i]=-1;
		}	
		ang[i]=tmp;		
	}
}
__global__ void adcig_get_dip(int nnx, int nnz, int ncdipg, float *up, float *up1, float *us, float *us1,float *uflux,float *uflux1,float *ufluz,float *ufluz1,float *upp_adcig,float *ups_adcig,float *rps)
{
	float tmp,tmp1,tmp2,tmp3,tmp4,tmp5,a1,b1,plr,tmp11,tmp21;
	int index,dipang;
	int i=blockIdx.x * blockDim.x + threadIdx.x;
	float bb1,bb2;
	float ang,ang1,y1;
	//int ncdipg=91;

	if(i<nnx*nnz){
		/*tmp1=ufluz[i];
		tmp2=-uflux[i];
		if(fabs(tmp1)>1.0e-20||fabs(tmp2)>1.0e-20){
			tmp=acos(tmp1/sqrt(tmp1*tmp1+tmp2*tmp2));	
			if(tmp2>=0){
				tmp*=-1;
			}
		}else{
			tmp=PI;
		}
		ang=tmp;

		tmp1=-ufluz1[i];
		tmp2=-uflux1[i];
		if(fabs(tmp1)>1.0e-20||fabs(tmp3)>1.0e-20){
			tmp=acos(tmp1/sqrt(tmp1*tmp1+tmp2*tmp2));	
			if(tmp2<0){
				tmp*=-1;
			}
		}else{
			tmp=0;
		}
		ang1=tmp;
		if(ufluz[i]*ufluz1[i]<0 || uflux[i]*uflux1[i]<0){
			if(fabs(ang-ang1)<PI*0.5){
				if(ang>=ang1){
					y1=1.0;
				}else{
					y1=-1.0;
				}
				a1=0.5*(ang+ang1);
				if(a1>0.5*PI){
					a1=PI-a1;
				}
				if(a1<-0.5*PI){
					a1=-PI-a1;
				}
				dipang=(2.0*a1/PI+1)*(ncdipg/2);
				upp_adcig[i*ncdipg+dipang]+=up[i]*up1[i];			
				ups_adcig[i*ncdipg+dipang+10]+=up[i]*us1[i]*y1;
			}
		}//*/
		tmp1=uflux[i];
		tmp2=uflux1[i];
		tmp3=ufluz[i];
		tmp4=ufluz1[i];
		tmp=tmp1*tmp2+tmp3*tmp4;
		if(tmp<0){

			tmp=tmp1*tmp4-tmp2*tmp3;
			plr=1;
			if(tmp<0){plr=-1;}

			tmp11=tmp1-tmp2;
			tmp21=tmp3-tmp4;
			a1=atan(tmp11/tmp21);
			a1+=PI2;
			a1=fabs(a1)/PI;
			tmp=1;
			if(tmp21<0){tmp=-1;}
			dipang=a1*(ncdipg-1);
			index=i*ncdipg+dipang;
			atomicAdd(&upp_adcig[index],up[i]*up1[i]*tmp);

			tmp11=tmp1-tmp2*1.5;
			tmp21=tmp3-tmp4*1.5;
			b1=atan(tmp11/tmp21);
			b1+=PI2;
			b1=fabs(b1)/PI;
			tmp=1;
			if(tmp21<0){tmp=-1;}
			dipang=b1*(ncdipg-1);
			index=i*ncdipg+dipang;//*/
			atomicAdd(&ups_adcig[index],up[i]*us1[i]*tmp*plr);

		}//*/
	}
}

/************************************func***************************************/  
__global__ void illum(int nnx, int nnz, float *up, float *ss)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      if(id<nnx*nnz){
            ss[id]+=up[id]*up[id];
      }
}
/************************************func***************************************/  
__global__ void wave_seperate_diver_curl(int nnx, int nnz, float *P1, float *Q1, float dx, float dz, float *up, float *us)
{
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      int ix,iz;
      float P_x,P_z,Q_x,Q_z;
      ix=id/nnz;
      iz=id%nnz;           
      if(id>=0&&id<nnx*nnz){
            if(ix>=mm&&ix<(nnx-mm-1)&&iz>=mm&&iz<(nnz-mm-1)){
                  P_x=( 0.8*(P1[id+nnz]-P1[id-nnz]) - 0.2*(P1[id+2*nnz]-P1[id-2*nnz]) + 0.0381*(P1[id+3*nnz]-P1[id-3*nnz]) - 0.0036*(P1[id+4*nnz]-P1[id-4*nnz]) )/dx;
                  Q_x=( 0.8*(Q1[id+nnz]-Q1[id-nnz]) - 0.2*(Q1[id+2*nnz]-Q1[id-2*nnz]) + 0.0381*(Q1[id+3*nnz]-Q1[id-3*nnz]) - 0.0036*(Q1[id+4*nnz]-Q1[id-4*nnz]) )/dx;
                  P_z=( 0.8*(P1[id+1]-P1[id-1]) - 0.2*(P1[id+2]-P1[id-2]) + 0.0381*(P1[id+3]-P1[id-3]) - 0.0036*(P1[id+4]-P1[id-4]) )/dz;
                  Q_z=( 0.8*(Q1[id+1]-Q1[id-1]) - 0.2*(Q1[id+2]-Q1[id-2]) + 0.0381*(Q1[id+3]-Q1[id-3]) - 0.0036*(Q1[id+4]-Q1[id-4]) )/dz;
                  
                  up[id]= P_x + Q_z;
                  us[id]= Q_x - P_z;
            }
      }  
}
/************************************func***************************************/  
__global__ void wavefield_bndr(int nnx, int nnz, int nx, int nz, int npml, int it, int nt, 
                               float *P, float *Q, float *P_bndr, float *Q_bndr, bool flag)
{		
      int id=threadIdx.x+blockDim.x*blockIdx.x;
      if(id<2*nx+2*nz)
      {
            if(flag)
            /////////////////////////////////save boundary
             {
                  if(id<nx){//up
                        P_bndr[it*(2*nx+2*nz)+id]=P[npml-1+nnz*(id+npml)];
                        Q_bndr[it*(2*nx+2*nz)+id]=Q[npml-1+nnz*(id+npml)];
                  }else if(id>=nx&&id<(2*nx)){//down   
                        P_bndr[it*(2*nx+2*nz)+id]=P[npml+nz+1+nnz*(id-nx+npml)];
                        Q_bndr[it*(2*nx+2*nz)+id]=Q[npml+nz+1+nnz*(id-nx+npml)];
                        }else if(id>=(2*nx)&&id<(2*nx+nz)){//left
                              P_bndr[it*(2*nx+2*nz)+id]=P[id-2*nx+npml+nnz*(npml-1)];
                              Q_bndr[it*(2*nx+2*nz)+id]=Q[id-2*nx+npml+nnz*(npml-1)];
                              }else if(id>=(2*nx+nz)){//right
                                    P_bndr[it*(2*nx+2*nz)+id]=P[id-2*nx-nz+npml+nnz*(npml+nx+1)];
                                    Q_bndr[it*(2*nx+2*nz)+id]=Q[id-2*nx-nz+npml+nnz*(npml+nx+1)];
                              }
            }else{/////////////////////////////add boundary
                  if(id<nx){//up
                        P[npml-1+nnz*(id+npml)]=P_bndr[it*(2*nx+2*nz)+id];
                        Q[npml-1+nnz*(id+npml)]=Q_bndr[it*(2*nx+2*nz)+id];
                  }else if(id>=nx&&id<(2*nx)){//down
                        P[npml+nz+1+nnz*(id-nx+npml)]=P_bndr[it*(2*nx+2*nz)+id];
                        Q[npml+nz+1+nnz*(id-nx+npml)]=Q_bndr[it*(2*nx+2*nz)+id];
                        }else if(id>=(2*nx)&&id<(2*nx+nz)){//left
                              P[id-2*nx+npml+nnz*(npml-1)]=P_bndr[it*(2*nx+2*nz)+id];
                              Q[id-2*nx+npml+nnz*(npml-1)]=Q_bndr[it*(2*nx+2*nz)+id];
                              }else if(id>=(2*nx+nz)){//right
                                    P[id-2*nx-nz+npml+nnz*(npml+nx+1)]=P_bndr[it*(2*nx+2*nz)+id];
                                    Q[id-2*nx-nz+npml+nnz*(npml+nx+1)]=Q_bndr[it*(2*nx+2*nz)+id];
                              }
            }
      }       
}  

